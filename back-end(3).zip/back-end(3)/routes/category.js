const express = require("express")
const router = express.Router()

//import controller
const { create, list, remove } = require("../controllers/category")
const { authCheck, adminCheck } = require("../middleware/authcheck")


router.post("/category", authCheck, adminCheck, create)
router.get("/category",list)
router.delete("/category/:id", authCheck, adminCheck, remove)





module.exports = router