const express = require("express")
const router = express.Router()

//import controller
const { authCheck } = require("../middleware/authcheck")
const { getOrderAdmin, changeOrderStatus } = require("../controllers/admin")


router.put("/admin/order-status", authCheck, changeOrderStatus)
router.get("/admin/orders", authCheck, getOrderAdmin)


module.exports = router