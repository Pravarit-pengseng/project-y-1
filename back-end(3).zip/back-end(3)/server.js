const express = require("express")
const app = express()
const morgan = require("morgan")


const { readdirSync } = require("fs")
const cors = require("cors")


//const authRouter = require("./routes/auth")
//const categoryRouter = require("./routes/category")


// middleware
app.use(morgan("dev"))
app.use(express.json({ limit: "20mb" })) // limit large file images
app.use(cors())

//app.use("/api",authRouter)
//app.use("/api",categoryRouter)

readdirSync("./routes").map((item) => app.use("/api", require("./routes/" + item)))









// start server
app.listen(5000, () => console.log("Server is running on port 5000"))